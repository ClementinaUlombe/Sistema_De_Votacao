/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./src/**/*.{js,jsx,ts,tsx}", // Adicionando a pasta src e seus arquivos JavaScript e JSX
  ],
  theme: {
    extend: {},
  },
  plugins: [],
}
